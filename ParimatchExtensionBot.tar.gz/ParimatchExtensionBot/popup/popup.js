﻿// (function () {
//     // here can be some boot code  
//     var backgroundPage = chrome.extension.getBackgroundPage();
//     document.querySelector("#Button1").addEventListener("click", function () {
//         backgroundPage.handleButton1Click(); // this function is in background.js
//     });
//    
//     document.querySelector("#openTab").addEventListener("click", function () {
//         backgroundPage.openNewTab(); // this function is in background.js
//     })
// }());


