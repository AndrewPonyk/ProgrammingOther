package com.ap.config;

public class PubSubConfig {
}
