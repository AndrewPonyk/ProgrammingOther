// content scripts can be applied directly to page and page dom
// but there are a lot a limitations

console.log("This is content script");

var betInterval = setInterval(function () {
    console.log("Content script timeout 700: " + document.location.href);
    var curBalanceElement = document.querySelector("#ownerInfo tr td:nth-child(7)");
    var betHistory = localStorage.getItem("betHistory") || "";

    if (!curBalanceElement){
        return;
    }

    var betText = document.querySelector("#wb").innerText;
    var currBalance = curBalanceElement.innerText ? parseFloat(curBalanceElement.innerText) : 0;
    var validBets = true;
    if(betText.indexOf("1.05") > 0 || betText.indexOf("1.06") > 0 || betText.indexOf("1.07") > 0
        || betText.indexOf("1.08") > 0 || betText.indexOf("1.08") > 0 || betText.indexOf("1.09") > 0 ){
        // bet can change coef, so it became invalid
        validBets = false;
    }
    if (currBalance >= 3 && validBets) {
        if (document.querySelector("#stakeNo[style='color:red']")) {
            window.close();
        }

        if(document.querySelector("input[name=sums]")){
            document.querySelector("input[name=sums]").value = "3";
        }

        var expressBetElement = document.querySelector("#r1");

        if (expressBetElement) {
            expressBetElement.click();
            var expressBetCoef = document.querySelector("label[for=r1]").innerText.replace(/[^\d\\.]/g,'').replace(/^\.+/g,'');
            if (expressBetCoef >= 1.15){
                window.close();
            }

            // it is available balance
            //document.querySelector("input[name=sums]").value = parseFloat(document.querySelector("#ownerInfo tr td:nth-child(7)").innerText);
        }

        var betsTableRows = document.querySelectorAll("#wb tr[id]");
        var currentBetInfo = "", duplicateFlag = true;
        for ( var i = 0; i < betsTableRows.length; i++) {
            if(!betsTableRows[i].querySelector("td:nth-child(4)").innerText.trim()){
                continue;
            }
            // time check
            if(!checkTimeFromEventStart(betsTableRows[i].querySelector("td:nth-child(4)").innerText.trim(),
                    betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim())){
                duplicateFlag = false;
                console.log("Time: " + new Date() + betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim());
                localStorage.setItem("wrongBetItems",     localStorage.getItem("wrongBetItems") +
                    ";Time:" + betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim() );
                //alert("time check: " + betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim());
                document.title = document.title + "; TIME Exlude " + betsTableRows[i].querySelector("td:nth-child(5)").innerText;
            }

            if(betHistory.indexOf(betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim()) >=0 ){
                console.log("Duplicate: " + new Date() + betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim());
                duplicateFlag = false;
                localStorage.setItem("wrongBetItems",     localStorage.getItem("wrongBetItems") +
                    "Duplicate: " + betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim() );
                //alert("duplicate check " + betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim());
                document.title = document.title + "; Duplicate Exlude " + betsTableRows[i].querySelector("td:nth-child(5)").innerText;
            }

            var betInfo = betsTableRows[i].querySelector("td:nth-child(4)").innerText.trim() + "__" +
                betsTableRows[i].querySelector("td:nth-child(5)").innerText.trim() + "__" +
                new Date() + ";"
            currentBetInfo += betInfo;
        }

        if(duplicateFlag){
            betHistory += currentBetInfo;
            betHistory += "     ;";// delimiter:)
            localStorage.setItem("betHistory", betHistory);
            //alert("PERFORM BET");
            document.querySelector("#do_stake").click();
        } else {
            //alert(localStorage.getItem("wrongBetItems"));
            //alert("some problem");
        }
    }
    setTimeout(function(){window.close()}, 2900);// close window after bet
}, 2500);


// ------------------------------------------------- DOM
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    /* If the received message has the expected format... */
    if (!msg.text) {
        return;
    }
    if (msg.text == "make_bet_selection") {
        var links = document.querySelectorAll("a i.blank, a i.down");
        selectBets(links);
    } else if (msg.text == "confirm_bet") {
        set3UAHAndFocusConfirmButton();
    } else if (msg.text == "check_balance_and_bet") {
        checkBalanceAndBet();
    }
});

function selectBets(betLinks, maxBets) {
    console.log("Start selecting bets");
    maxBets = maxBets || 4;
    var counter = 0;
    document.title = "";
    for (var i = 0; i < betLinks.length; i++) {
        var betRowCompetitions = betLinks[i].closest("div").previousElementSibling.innerText;

        if (betLinks[i].innerText <= "1.04" && checkBet(betRowCompetitions)) {
            var betTitle = betLinks[i].closest("tr").querySelector("td:nth-child(2) a").firstChild.nodeValue ?
                betLinks[i].closest("tr").querySelector("td:nth-child(2) a").firstChild.nodeValue.trim()
                :betLinks[i].closest("tr").querySelector("td:nth-child(2) a").querySelector("small").innerText;

            var previouslyWrongBetItems = localStorage.getItem("wrongBetItems") || "";
            if(previouslyWrongBetItems.indexOf(betTitle) >= 0){
                document.title = document.title + "; Excluded " + betTitle;
                //alert("exclude " + betTitle);
                continue;
            }
            betLinks[i].click();
            counter++;
        }

        if(counter >= maxBets){
            break;
        }
    }
    console.log(new Date() + "Excluded : " + previouslyWrongBetItems);
    localStorage.setItem("wrongBetItems", "");
    if(counter > 1){
        document.querySelector(".btn_orange").click();
    }
}

function set3UAHAndFocusConfirmButton() {
    document.querySelector("input[name=sums]").value = 3;
    document.querySelector("input[type=radio][onclick='enableSingle();']").click();
    document.querySelector("#do_stake").focus();
}

function checkBalanceAndBet() {
    var links = document.querySelectorAll("a i.blank, a i.down");
    selectBets(links);
}

// ---------------------------------------------------- Utils
function checkBet(betRowText) {
    //TODO:
    // make conditions
    if (betRowText.toLowerCase().indexOf("статистика") >= 0) {
        return false;
    }

    if (betRowText.indexOf("U-13") >= 0 || betRowText.indexOf("U-14") >= 0 || betRowText.indexOf("U-15") >= 0 || betRowText.indexOf("U-16") >= 0 || betRowText.indexOf("U-17") >= 0
        || betRowText.indexOf("U-18") >= 0 || betRowText.indexOf("U-19") >= 0) {
        return false;
    }

    if (betRowText.toLowerCase().indexOf("мол.") >= 0 || betRowText.toLowerCase().indexOf("молод") >= 0) {
        return false;
    }

    // skip friendly games
    if (betRowText.toLowerCase().indexOf("товари") >= 0) {
        return false;
    }

    // skip regional league
    if (betRowText.toLowerCase().indexOf("регионал") >= 0) {
        return false;
    }

    if (betRowText.toLowerCase().indexOf("микст") >= 0) {
        return false;
    }

    if (betRowText.toLowerCase().indexOf("дартс") >= 0) {
        return false;
    }

    if (betRowText.toLowerCase().indexOf("бильярд") >= 0) {
        return false;
    }

    if (betRowText.toLowerCase().indexOf("на траве") >= 0) {
        return false;
    }

    //??? I dont know, should I add
    if (betRowText.toLowerCase().indexOf("киберспорт") >= 0) {
        return false;
    }

    return true;
}

function checkTimeFromEventStart(datetime, event) {
    var now = new Date();
    var before = new Date();

    var time = datetime.substr(datetime.length - 5).split(":");
    before.setHours(time[0]);
    before.setMinutes(time[1]);

    var diffMinutes = (now - before) / 60000;
    var betTitle = event.toLowerCase();
    console.log(betTitle + "----->" + diffMinutes);
    if (event && betTitle.indexOf("теннис") >= 0 &&
        event && betTitle.indexOf("настоль") < 0) {
        return diffMinutes > 58;
    }

    if (event && betTitle.indexOf("волейб") >= 0) {
        return diffMinutes > 25;
    }

    if (event && betTitle.indexOf("бадминтон") >= 0) {
        return diffMinutes > 45;
    }

    if (event && betTitle.indexOf("настоль") >= 0) {
        return diffMinutes > 32;
    }

    if (event && betTitle.indexOf("футбол") >= 0) {
        return diffMinutes > 25;
    }

    if (event && betTitle.indexOf("баскетб") >= 0) {
        return diffMinutes > 33;
    }

    if (event && betTitle.indexOf("гандбол") >= 0) {
        console.log("Гандбол , tim diff " + diffMinutes);
        return diffMinutes > 24;
    }

    if (event && betTitle.indexOf("футзал") >= 0) {
        return diffMinutes > 32;
    }


    return true;
}

function isVisible(elem) {
    return !!( elem.offsetWidth || elem.offsetHeight || elem.getClientRects().length );
}

function validateBetCountAndCoeficients() {
    // no more, than 5 bets and coef <=1.04
}